"""LAB_ONLY provenance metadata; business code remains src.*."""
